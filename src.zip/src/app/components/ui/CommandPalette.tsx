"use client";

import { HTMLAttributes, forwardRef, useState, useEffect, useRef, useCallback, type ReactNode, type KeyboardEvent } from "react";
import { createPortal } from "react-dom";
import { Search, Clock, ChevronRight, Command, Search as SearchIcon } from "lucide-react";
import { getShortcutDisplay, matchesShortcut, normalizeShortcut } from "@/lib/platform";

export interface CommandAction {
  id: string;
  label: string;
  icon?: ReactNode;
  shortcut?: string[];
  section?: string;
  onClick: () => void;
}

export interface CommandPaletteProps extends Omit<HTMLAttributes<HTMLDivElement>, "onSelect"> {
  actions: CommandAction[];
  recentActions?: CommandAction[];
  onSelect?: (action: CommandAction) => void;
  triggerShortcut?: string[];
  placeholder?: string;
  emptyMessage?: string;
}

export const CommandPalette = forwardRef<HTMLDivElement, CommandPaletteProps>(
  ({
    actions,
    recentActions = [],
    onSelect,
    triggerShortcut = ["Meta", "k"],
    placeholder = "Search commands...",
    emptyMessage = "No results found",
    className = "",
    ...props
  }, ref) => {
    const [isOpen, setIsOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState("");
    const [focusedIndex, setFocusedIndex] = useState(0);
    const inputRef = useRef<HTMLInputElement>(null);
    const listRef = useRef<HTMLDivElement>(null);

    const filteredActions = searchTerm
      ? actions.filter(action =>
          action.label.toLowerCase().includes(searchTerm.toLowerCase())
        )
      : actions;

    const groupedActions = filteredActions.reduce((acc, action) => {
      const section = action.section || "Actions";
      if (!acc[section]) acc[section] = [];
      acc[section].push(action);
      return acc;
    }, {} as Record<string, CommandAction[]>);

    const allActions = Object.values(groupedActions).flat();
    const showRecent = !searchTerm && recentActions.length > 0;

    // Normalize trigger shortcut for current platform
    const normalizedTriggerShortcut = normalizeShortcut(triggerShortcut);

    const handleOpen = useCallback(() => {
      setIsOpen(true);
      setSearchTerm("");
      setFocusedIndex(0);
    }, []);

    const handleClose = useCallback(() => {
      setIsOpen(false);
      setSearchTerm("");
    }, []);

    const handleSelect = useCallback((action: CommandAction) => {
      onSelect?.(action);
      action.onClick();
      handleClose();
    }, [onSelect, handleClose]);

    useEffect(() => {
      const handleKeyDown = (e: KeyboardEvent) => {
        if (matchesShortcut(e, normalizedTriggerShortcut)) {
          e.preventDefault();
          if (isOpen) handleClose(); else handleOpen();
        }
      };

      document.addEventListener("keydown", handleKeyDown as unknown as (e: Event) => void);
      return () => document.removeEventListener("keydown", handleKeyDown as unknown as (e: Event) => void);
    }, [isOpen, handleOpen, handleClose, normalizedTriggerShortcut]);

    useEffect(() => {
      if (isOpen && inputRef.current) {
        setTimeout(() => inputRef.current?.focus(), 0);
      }
    }, [isOpen]);

    useEffect(() => {
      setFocusedIndex(0);
    }, [searchTerm]);

    useEffect(() => {
      if (focusedIndex >= 0 && listRef.current) {
        const items = listRef.current.querySelectorAll('[role="option"]');
        items[focusedIndex]?.scrollIntoView({ block: "nearest" });
      }
    }, [focusedIndex]);

    const handleKeyboardNav = (e: KeyboardEvent<HTMLInputElement>) => {
      const totalItems = allActions.length + (showRecent ? recentActions.length : 0);

      switch (e.key) {
        case "ArrowDown":
          e.preventDefault();
          setFocusedIndex(prev => Math.min(prev + 1, totalItems - 1));
          break;
        case "ArrowUp":
          e.preventDefault();
          setFocusedIndex(prev => Math.max(prev - 1, 0));
          break;
        case "Enter":
          e.preventDefault();
          if (showRecent && focusedIndex < recentActions.length) {
            handleSelect(recentActions[focusedIndex]);
          } else if (focusedIndex < totalItems) {
            handleSelect(allActions[focusedIndex - (showRecent ? recentActions.length : 0)]);
          }
          break;
        case "Escape":
          handleClose();
          break;
      }
    };

    const renderShortcut = (shortcut?: string[]) => {
      if (!shortcut) return null;
      return (
        <div className="flex items-center gap-1">
          {shortcut.map((key, i) => (
            <kbd
              key={i}
              className="px-1.5 py-0.5 text-[8px] font-mono bg-gray-100 dark:bg-zinc-800 border border-gray-200 dark:border-zinc-700 rounded"
            >
              {key}
            </kbd>
          ))}
        </div>
      );
    };

    const renderContent = () => (
      <div
        ref={ref as React.Ref<HTMLDivElement>}
        className={`fixed inset-0 z-[200] ${className}`}
        {...props}
      >
        {/* Glassmorphism backdrop */}
        <div
          className="absolute inset-0 bg-black/60 backdrop-blur-md animate-in fade-in duration-200"
          onClick={handleClose}
        />

        {/* Dialog with glass effect */}
        <div className="absolute inset-x-4 top-[12%] mx-auto max-w-xl">
          <div className="bg-white/90 dark:bg-zinc-900/90 backdrop-blur-xl rounded-2xl shadow-2xl border border-white/20 dark:border-white/10 overflow-hidden animate-in zoom-in-95 fade-in duration-200">
            
            {/* Emerald gradient accent at top */}
            <div className="h-1 bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-500" />
            
            {/* Search input */}
            <div className="flex items-center gap-3 px-5 py-4 border-b border-gray-100/50 dark:border-zinc-800/50">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center shadow-md">
                <SearchIcon size={16} className="text-white" />
              </div>
              <input
                ref={inputRef}
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onKeyDown={handleKeyboardNav}
                placeholder={placeholder}
                className="flex-1 bg-transparent text-[13px] font-medium text-gray-900 dark:text-white outline-none placeholder:text-gray-400"
              />
              <div className="flex items-center gap-1.5 px-2 py-1 bg-gray-100/80 dark:bg-zinc-800/80 rounded-lg border border-gray-200/50 dark:border-zinc-700/50">
                <Command size={10} className="text-gray-400" />
                <kbd className="px-1 py-0.5 text-[9px] font-mono text-gray-500 dark:text-gray-400">K</kbd>
              </div>
            </div>

            {/* Results */}
            <div ref={listRef} className="max-h-80 overflow-y-auto custom-scrollbar">
              {/* Recent items */}
              {showRecent && (
                <div className="p-2">
                  <div className="px-3 py-2 text-[9px] font-bold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider flex items-center gap-2">
                    <Clock size={10} />
                    Recent
                  </div>
                  {recentActions.map((action, index) => (
                    <button
                      key={action.id}
                      role="option"
                      aria-selected={focusedIndex === index}
                      onClick={() => handleSelect(action)}
                      className={`
                        w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150
                        ${focusedIndex === index 
                          ? "bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/50 dark:to-teal-950/50 ring-2 ring-emerald-500/20" 
                          : "hover:bg-gray-50 dark:hover:bg-zinc-800/50"
                        }
                      `}
                    >
                      {action.icon && <span className="text-gray-400">{action.icon}</span>}
                      <span className="flex-1 text-[12px] font-medium text-gray-700 dark:text-gray-300">
                        {action.label}
                      </span>
                      {renderShortcut(action.shortcut)}
                    </button>
                  ))}
                </div>
              )}

              {/* Grouped actions */}
              {Object.entries(groupedActions).map(([section, sectionActions]) => (
                <div key={section} className="p-2">
                  <div className="px-3 py-2 text-[9px] font-bold text-gray-400 dark:text-gray-500 uppercase tracking-wider">
                    {section}
                  </div>
                  {sectionActions.map((action) => {
                    const actionIndex = allActions.indexOf(action) + (showRecent ? recentActions.length : 0);
                    return (
                      <button
                        key={action.id}
                        role="option"
                        aria-selected={focusedIndex === actionIndex}
                        onClick={() => handleSelect(action)}
                        className={`
                          w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-left transition-all duration-150
                          ${focusedIndex === actionIndex
                            ? "bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/50 dark:to-teal-950/50 ring-2 ring-emerald-500/20"
                            : "hover:bg-gray-50 dark:hover:bg-zinc-800/50"
                          }
                        `}
                      >
                        {action.icon && <span className="text-emerald-500">{action.icon}</span>}
                        <span className="flex-1 text-[12px] font-medium text-gray-700 dark:text-gray-300">
                          {action.label}
                        </span>
                        <ChevronRight size={14} className="text-gray-300" />
                        {renderShortcut(action.shortcut)}
                      </button>
                    );
                  })}
                </div>
              ))}

              {/* Empty state */}
              {filteredActions.length === 0 && !showRecent && (
                <div className="p-8 text-center">
                  <div className="w-12 h-12 mx-auto mb-3 rounded-xl bg-gray-100 dark:bg-zinc-800 flex items-center justify-center">
                    <Search size={20} className="text-gray-300 dark:text-gray-600" />
                  </div>
                  <p className="text-[11px] font-medium text-gray-400 uppercase tracking-wider">
                    {emptyMessage}
                  </p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="px-5 py-3 border-t border-gray-100/50 dark:border-zinc-800/50 bg-gradient-to-r from-gray-50/50 to-transparent dark:from-zinc-800/50 flex items-center justify-between">
              <div className="flex items-center gap-4">
                <span className="text-[9px] font-medium text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded bg-gray-200 dark:bg-zinc-700 flex items-center justify-center text-[8px] font-bold">↑</span>
                  Navigate
                </span>
                <span className="text-[9px] font-medium text-gray-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span className="w-4 h-4 rounded bg-gray-200 dark:bg-zinc-700 flex items-center justify-center text-[8px] font-bold">↵</span>
                  Select
                </span>
              </div>
              <span className="text-[9px] font-mono text-emerald-500 dark:text-emerald-400">
                {allActions.length} commands
              </span>
            </div>
          </div>
        </div>
      </div>
    );

    // Always render, but portal to body
    if (typeof window === "undefined") return null;
    return isOpen ? createPortal(renderContent(), document.body) : null;
  }
);

CommandPalette.displayName = "CommandPalette";

// Standalone trigger button for the command palette
export interface CommandPaletteTriggerProps extends HTMLAttributes<HTMLButtonElement> {
  shortcut?: string[];
}

export const CommandPaletteTrigger = forwardRef<HTMLButtonElement, CommandPaletteTriggerProps>(
  ({ shortcut = ["Meta", "k"], className = "", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={`
          flex items-center gap-3 px-4 py-3 
          bg-white/80 dark:bg-zinc-900/80 backdrop-blur-xl
          border border-gray-200/50 dark:border-zinc-700/50 
          rounded-xl hover:border-emerald-300 dark:hover:border-emerald-700
          text-[11px] font-medium text-gray-500 dark:text-gray-400
          hover:text-gray-700 dark:hover:text-gray-200
          transition-all duration-200 hover:shadow-lg hover:shadow-emerald-500/5
          ${className}
        `}
        {...props}
      >
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-gray-100 to-gray-50 dark:from-zinc-800 dark:to-zinc-900 flex items-center justify-center">
          <Search size={14} className="text-gray-400" />
        </div>
        <span className="flex-1 text-left">Search commands...</span>
        <div className="flex items-center gap-1">
          {shortcut.map((key, i) => (
            <kbd
              key={i}
              className="px-1.5 py-0.5 text-[9px] font-mono bg-gray-100/80 dark:bg-zinc-800/80 border border-gray-200/50 dark:border-zinc-700/50 rounded"
            >
              {key}
            </kbd>
          ))}
        </div>
      </button>
    );
  }
);

CommandPaletteTrigger.displayName = "CommandPaletteTrigger";