"use client";

import { useState, useEffect } from "react";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useTheme } from "next-themes";
import { Sun, Moon, LogOut, LayoutDashboard, Package, FileText, Settings, ClipboardList } from "lucide-react";
// 1. Import QueryClient hooks and Actions
import { useQueryClient, useQuery } from "@tanstack/react-query";
import { 
  getInventory, 
  getBoms, 
  getSalesOrders, 
  getInwardHistory 
} from "./actions";

// Components
import DashboardView from "./components/DashboardView";
import InventoryView from "./components/InventoryView";
import BomView from "./components/BomView";
import OrderBook from "./components/OrderBook";
import InwardLedger from "./components/InwardLedger";
import Sidebar from "./components/Sidebar";
import SettingsView from "./components/SettingsView";
import DashboardStats from "./components/DashboardStats";
import TopProducts from "./components/TopProducts";
import { TableSkeleton } from "./components/ui/TableSkeleton"; 
import { Button } from "./components/ui/Button";
import { CommandPalette, CommandPaletteTrigger, type CommandAction } from "./components/ui/CommandPalette";
import { KeyboardShortcutsHelp } from "./components/composite/KeyboardShortcutsHelp";
import { RealTimeNotifications } from "./components/composite/RealTimeUpdates";
import { matchesShortcut, normalizeShortcut } from "@/lib/platform";

export const dynamic = "force-dynamic";

export default function Page() {
  const { data: session, status } = useSession();
  const router = useRouter();
  const queryClient = useQueryClient(); 
  
  // UI State
  const [activeTab, setActiveTab] = useState("dashboard");
  const [mounted, setMounted] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  const [isSidebarHovered, setIsSidebarHovered] = useState(false);
  const [showKeyboardHelp, setShowKeyboardHelp] = useState(false);
  const { theme, setTheme } = useTheme();

  // Track g-key for keyboard navigation shortcuts
  const [gKeyPressed, setGKeyPressed] = useState(false);

  /**
   * ROLE-BASED ACCESS CONTROL (RBAC)
   * If a staff member logs in, they should not start on the Dashboard.
   * We automatically redirect them to the Sales Orders (Order Book).
   */
  const isAdmin = session?.user?.role === "ADMIN";

  useEffect(() => {
    if (status === "authenticated" && !isAdmin && activeTab === "dashboard") {
      setActiveTab("orders"); // Redirect Staff to Orders by default
    }
  }, [status, isAdmin, activeTab]);

  // 2. MAIN PREFETCH LOGIC: Syncs all tabs immediately after login
  useEffect(() => {
    if (status === "authenticated") {
      const prefetchAppData = async () => {
        try {
          await Promise.all([
            queryClient.prefetchQuery({ queryKey: ["inventory"], queryFn: getInventory }),
            queryClient.prefetchQuery({ queryKey: ["boms"], queryFn: getBoms }),
            queryClient.prefetchQuery({ queryKey: ["salesOrders"], queryFn: getSalesOrders }),
            queryClient.prefetchQuery({ queryKey: ["inwardHistory"], queryFn: getInwardHistory }),
          ]);
        } catch (error) {
          console.error("Prefetch failed:", error);
        }
      };
      prefetchAppData();
    }
  }, [status, queryClient]);

  // 3. DATA HOOK: Used for checking if we have data to show
  const { data: inventory = [], isLoading: isInventoryLoading } = useQuery({
    queryKey: ["inventory"],
    queryFn: getInventory,
    enabled: status === "authenticated", 
  });

  useEffect(() => {
    if (status === "unauthenticated") {
      router.push("/api/auth/signin");
    }
  }, [status, router]);

  useEffect(() => {
    setMounted(true);
  }, []);

  // Keyboard navigation shortcuts (g+d, g+p, g+r, g+s, etc.)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Don't trigger shortcuts when typing in inputs
      if (e.target instanceof HTMLInputElement || e.target instanceof HTMLTextAreaElement) {
        return;
      }

      const key = e.key.toLowerCase();

      // Check for g-key to start navigation sequence (no modifier)
      if (key === "g" && !e.metaKey && !e.ctrlKey && !e.shiftKey && !e.altKey) {
        setGKeyPressed(true);
        // Clear after 500ms to prevent stuck state
        setTimeout(() => setGKeyPressed(false), 500);
        return;
      }

      // If g was pressed, check for second key
      if (gKeyPressed) {
        switch (key) {
          case "d":
            e.preventDefault();
            setActiveTab("dashboard");
            break;
          case "p":
            e.preventDefault();
            setActiveTab("inventory");
            break;
          case "r":
            e.preventDefault();
            router.push("/reports");
            break;
          case "s":
            e.preventDefault();
            setActiveTab("settings");
            break;
          case "o":
            e.preventDefault();
            setActiveTab("orders");
            break;
          case "i":
            e.preventDefault();
            setActiveTab("inward");
            break;
        }
        setGKeyPressed(false);
        return;
      }

      // ? to toggle keyboard shortcuts help (Shift+/ on both platforms)
      if (e.shiftKey && e.key === "/") {
        e.preventDefault();
        setShowKeyboardHelp(true);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "g") {
        setGKeyPressed(false);
      }
    };

    window.addEventListener("keydown", handleKeyDown);
    window.addEventListener("keyup", handleKeyUp);
    return () => {
      window.removeEventListener("keydown", handleKeyDown);
      window.removeEventListener("keyup", handleKeyUp);
    };
  }, [gKeyPressed, router]);

  // Guard Clause: Handles initial loading states
  if (!mounted || status === "loading") {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-background text-zinc-500">
        <div className="text-[10px] font-black uppercase tracking-[0.5em] animate-pulse">
          Initializing System...
        </div>
      </div>
    );
  }

  if (!session) return null;

  const lowStockAlertCount = inventory.filter((item: any) => item.quantityOnHand < 20).length;

  const menuItems = [
    { id: "dashboard", label: "Dashboard", icon: "📊" },
    { id: "inventory", label: "Inventory", icon: "📦" },
    { id: "inward", label: "Stock Inward", icon: "📥" },
    { id: "boms", label: "BOM Manager", icon: "🛠" },
    { id: "orders", label: "Sales Orders", icon: "📝" },
    { id: "settings", label: "Settings", icon: "⚙️" }, 
  ];

  // Command palette actions
  const commandActions: CommandAction[] = [
    {
      id: "nav-dashboard",
      label: "Go to Dashboard",
      icon: <LayoutDashboard size={14} />,
      shortcut: ["g", "d"],
      section: "Navigation",
      onClick: () => setActiveTab("dashboard"),
    },
    {
      id: "nav-inventory",
      label: "Go to Products",
      icon: <Package size={14} />,
      shortcut: ["g", "p"],
      section: "Navigation",
      onClick: () => setActiveTab("inventory"),
    },
    {
      id: "nav-reports",
      label: "Go to Reports",
      icon: <FileText size={14} />,
      shortcut: ["g", "r"],
      section: "Navigation",
      onClick: () => router.push("/reports"),
    },
    {
      id: "nav-settings",
      label: "Go to Settings",
      icon: <Settings size={14} />,
      shortcut: ["g", "s"],
      section: "Navigation",
      onClick: () => setActiveTab("settings"),
    },
    {
      id: "nav-orders",
      label: "Go to Orders",
      icon: <ClipboardList size={14} />,
      shortcut: ["g", "o"],
      section: "Navigation",
      onClick: () => setActiveTab("orders"),
    },
    {
      id: "action-theme",
      label: theme === "dark" ? "Switch to Light Mode" : "Switch to Dark Mode",
      icon: theme === "dark" ? <Sun size={14} /> : <Moon size={14} />,
      section: "Actions",
      onClick: () => setTheme(theme === "dark" ? "light" : "dark"),
    },
    {
      id: "help-shortcuts",
      label: "Keyboard Shortcuts",
      icon: <span className="text-[14px]">?</span>,
      shortcut: ["?"],
      section: "Help",
      onClick: () => setShowKeyboardHelp(true),
    },
  ];
  return (
    <div className="flex h-screen bg-background text-foreground font-sans overflow-hidden transition-colors duration-500">
      {isSidebarCollapsed && isSidebarHovered && (
        <div className="fixed inset-0 bg-black/10 dark:bg-black/60 backdrop-blur-[2px] z-40 animate-in fade-in duration-300" />
      )}

      <div className="hidden md:block">
        <Sidebar 
          activeTab={activeTab} 
          setActiveTab={setActiveTab} 
          menuItems={menuItems} 
          badgeCount={lowStockAlertCount}
          isCollapsed={isSidebarCollapsed}
          setIsCollapsed={setIsSidebarCollapsed}
          setIsSidebarHovered={setIsSidebarHovered}
        />
      </div>

      <div className={`flex-1 flex flex-col min-w-0 transition-all duration-500 ease-in-out bg-background dark:bg-[#060606] ${
        isSidebarCollapsed ? "md:pl-20" : "md:pl-72"
      }`}>
        
        <header className="h-16 md:h-20 bg-background/40 dark:bg-black/40 backdrop-blur-md border-b border-gray-200/50 dark:border-white/5 px-4 md:px-10 flex items-center justify-between shrink-0 z-10 sticky top-0">
          <div className="flex flex-col text-left">
            <h2 className="text-[10px] font-black text-gray-400 dark:text-zinc-600 uppercase tracking-[0.5em] mb-1 text-left">System Root</h2>
            <div className="flex items-center gap-2">
              <div className="w-1 h-1 bg-foreground rounded-full"></div>
              <span className="text-[11px] font-black uppercase tracking-widest italic text-foreground">
                {menuItems.find(m => m.id === activeTab)?.label}
              </span>
            </div>
          </div>
          
          <div className="flex items-center gap-2 md:gap-4">
            <CommandPaletteTrigger />
            <RealTimeNotifications />
            <Button 
              variant="ghost"
              size="sm"
              onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
              className="w-10 h-10"
            >
              {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            </Button>
            
            <Button 
              variant="ghost"
              size="sm"
              onClick={() => signOut({ callbackUrl: "/login" })}
              className="w-10 h-10 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-950/20"
              title="Logout"
            >
              <LogOut size={16} />
            </Button>
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 md:p-12 pb-24 md:pb-12">
          <div className="max-w-[1200px] mx-auto">
            {inventory.length === 0 && isInventoryLoading ? (
              <TableSkeleton />
            ) : (
              <div className="animate-in fade-in slide-in-from-bottom-6 duration-700 ease-out">
                {/* ADMIN ONLY SECTIONS */}
                {activeTab === "dashboard" && isAdmin && (
                  <div className="space-y-8">
                    <DashboardStats /> 
                    <DashboardView />
                    <TopProducts />
                  </div>
                )}
                
                {activeTab === "inventory" && <InventoryView />}
                {activeTab === "inward" && <InwardLedger />}
                {activeTab === "boms" && <BomView />}
                {activeTab === "orders" && <OrderBook />}

                {/* ADMIN ONLY SETTINGS */}
                {activeTab === "settings" && isAdmin && <SettingsView />}

                {/* FALLBACK FOR UNAUTHORIZED TABS */}
                {((activeTab === "dashboard" || activeTab === "settings") && !isAdmin) && (
                  <div className="h-[60vh] flex flex-col items-center justify-center text-center">
                    <div className="w-16 h-16 bg-rose-50 rounded-3xl flex items-center justify-center text-rose-500 mb-4">
                       <LogOut size={32} />
                    </div>
                    <h3 className="text-sm font-black uppercase italic tracking-tight">Access Restricted</h3>
                    <p className="text-[10px] text-gray-400 uppercase font-bold tracking-widest mt-2 max-w-[200px]">
                      Your STAFF account does not have permission to view this department.
                    </p>
                    <Button 
                      variant="primary"
                      onClick={() => setActiveTab("orders")}
                      className="mt-6"
                    >
                      Return to Orders
                    </Button>
                  </div>
                )}
              </div>
            )}
          </div>
        </main>
      </div>

      <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-background/80 dark:bg-black/80 backdrop-blur-lg border-t border-gray-200 dark:border-white/10 z-50 px-4 py-3">
        <div className="flex justify-between items-center max-w-md mx-auto">
          {/* Hide Dashboard and Settings from Mobile nav for Staff */}
          {menuItems
            .filter(item => !(!isAdmin && ["dashboard", "settings"].includes(item.id)))
            .map((item) => (
              <button
                key={item.id}
                onClick={() => setActiveTab(item.id)}
                className={`flex flex-col items-center gap-1 transition-all ${
                  activeTab === item.id ? "text-foreground" : "text-gray-400 dark:text-gray-600"
                }`}
              >
                <span className="text-lg">{item.icon}</span>
                <span className="text-[8px] font-black uppercase tracking-tighter">
                  {item.label.split(' ')[0]}
                </span>
              </button>
            ))
          }
        </div>
      </nav>

      {/* Global Command Palette */}
      <CommandPalette
        actions={commandActions}
        triggerShortcut={["Meta", "k"]}
        placeholder="Search commands, navigate, or find..."
      />

      {/* Keyboard Shortcuts Help Modal */}
      <KeyboardShortcutsHelp
        isOpen={showKeyboardHelp}
        onClose={() => setShowKeyboardHelp(false)}
      />
    </div>
  );
}